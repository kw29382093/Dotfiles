#!/bin/bash

echo "super user"
sudo su
123

echo "atualizando banco de dados"
pacman -Sy

echo "instalando pacotes basicos"
pacman -S --noconfirm flatpak nano firefox git papirus-icon-theme nano alacritty picom geany gufw neovim rofi  

echo "istaladno flatpaks"
#flatpak install flathub org.kde.okular -y
#flatpak install flathub md.obsidian.Obsidian -y
flatpak install flathub io.github.flattool.Warehouse -y
#flatpak install flathub com.librumreader.librum -y 

echo "nvchad"
git clone https://github.com/NvChad/starter ~/.config/nvim && nvim 

echo "yay"
pacman -S --needed git base-devel && git clone https://aur.archlinux.org/yay.git && cd yay && makepkg -si
yay -Y --gendb

echo "arquivos de configuraçoes"
rm -rf/.config/qtile/config.py
cd Downloads/auto
mv config.py/.config/qtile

echo "papel de parede"
nitrogen --set-zoom-fill /home/kauan/Downloads/auto/black-cat-shadow-2k-wallpaper-uhdpaper.com-335@0@k.jpg

